import { Component, OnInit } from '@angular/core';
import { User } from 'src/models/app.user.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from 'src/services/UserService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-changed-password',
  templateUrl: './changed-password.component.html',
  styleUrls: ['./changed-password.component.css']
})
export class ChangedPasswordComponent implements OnInit {

  user: User;
  token: string;
  // roles: Array<Role>;
  message: string;
  frmUser: FormGroup;
  userName: string;

  constructor(private userServ: UserService , private route: Router) {
      this.user = new User('', '', '', 0);
      // this.roles = new Array<Role>();
      this.token = sessionStorage.getItem('token');
      this.message = '';
      this.userName = sessionStorage.getItem('userName');
      this.frmUser = new FormGroup({
        userName: new FormControl(this.userName,
                                          Validators.compose([
                                            Validators.nullValidator,
                                            Validators.required,
                                            Validators.pattern('[a-zA-Z]*')
                                          ])
                                           ),
        password: new FormControl(this.user.password,
                                          Validators.compose([
                                            Validators.nullValidator,
                                            Validators.required,
                                            Validators.pattern('[a-zA-Z0-9]*')
                                          ])
                                            )

      });
  }

  ngOnInit() {
  }

  updatepassword() {
    this.user = this.frmUser.value;
    console.log(this.frmUser.value);
    this.userServ.updateUserPassword( this.user, this.token).subscribe(
      resp => {
        this.message = resp.json().message;
      }
    );
    this.clear();
  }

  clear() {
    // this.role = new Role(0, '');
    this.message = '';
    this.user = new User('', '', '', 0);
  }

}
