import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  showdrop = false;
  showdrop1 = false;
  showdrop2 = false;
  flag: string;
  roleName: string;
  userName: string;

  constructor(private router: Router) {
    this.flag = '';
   }


  ngOnInit() {
    this.roleName = sessionStorage.getItem('roleName');
    this.userName = sessionStorage.getItem('userName');
    if (this.roleName === 'Admin') {
        this.flag = 'allGrant';
    } else if (this.roleName === 'Operator') {
        this.flag = 'noGrant';
    }
  }

  showdropdown(): void {
    this.showdrop = !this.showdrop;
    this.showdrop1 = false;
    this.showdrop2 = false;

  }
  showdropdown1(): void {
    this.showdrop2 =  !this.showdrop1;
    this.showdrop = false;
    this.showdrop2 = false;
  }

  showdropdown2(): void {
    this.showdrop2 =  !this.showdrop2;
    this.showdrop = false;
    this.showdrop1 = false;
  }
  dashboard() {
    this.router.navigate(['dashboard/home']);
  }

}
