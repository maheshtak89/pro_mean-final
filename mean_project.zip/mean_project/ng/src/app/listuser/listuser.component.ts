import { Component, OnInit } from '@angular/core';
import { User } from 'src/models/app.user.model';
import { FormGroup } from '@angular/forms';
import { UserService } from 'src/services/UserService';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {
  user: User;
  token: string;
  users: Array<User>;
  userHeaders: Array<string>;

  constructor(private userServ: UserService, private router: Router) {
    this.user = new User('', '', '', 0);
    this.users = new Array<User>();
    this.userHeaders = new Array<string>('UserName', 'Email');
    this.token = sessionStorage.getItem('token');
  }

  ngOnInit() {
      this.userServ.getUserData(this.token).subscribe(
        (resp: Response) => {
            this.users = resp.json().data;
        },
        error => {
          console.log(`Error Occured ${error}`);
        }
    );
  }

    addInfo(userName, roleId) {
      this.updateInfo(userName, roleId);
    }
    updateInfo(userName, roleId) {
    const navigationExtras: NavigationExtras = {
          queryParams: {
              'userName': userName,
              'roleId' : roleId
          }
      };
      this.router.navigate(['addInfo'],navigationExtras);
    }
}
