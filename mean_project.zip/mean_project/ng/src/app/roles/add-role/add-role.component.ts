import { Component, OnInit } from '@angular/core';

import { Role } from './../../../models/app.role.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RoleService } from 'src/services/RoleService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit {

  role: Role;
  token: string;
  // roles: Array<Role>;
  message: string;
  frmRole: FormGroup;
  roleName: string;

  constructor(private roleserv: RoleService , private route: Router) {
      this.role = new Role(0, '');
      // this.roles = new Array<Role>();
      this.token = sessionStorage.getItem('token');
      this.message = '';
      this.roleName = sessionStorage.getItem('roleName');
      this.frmRole = new FormGroup({
        roleId: new FormControl(this.role.roleId,
                                          Validators.compose([
                                            Validators.required
                                          ])
                                          ),
        roleName: new FormControl(this.role.roleName,
                                          Validators.compose([
                                            Validators.nullValidator,
                                            Validators.required,
                                            Validators.pattern('[a-zA-Z]*')
                                          ])
                                           )
      });
  }

  ngOnInit() {
  }

  save() {
      this.role = this.frmRole.value;
      // this.roleserv.postRoleData(this.role, this.token).subscribe(
      //     (resp: Response) => {
      //      this.message = resp.json().message;
      //     },
      //     error => {
      //       console.log(`Error Occured ${error}`);
      //     }
      //   );
      this.roleserv.postRoleData( this.role, this.token).subscribe(
        resp => {
          this.message = resp.json().message;
        }
      );
      this.clear();
  }

  clear() {
    this.role = new Role(0, '');
    this.message = '';
  }
}
