import { Role } from './../model/role.model';
import { Roles } from './../model/role.model.data';

export class RoleLogic {
    private roles: Array<Role>;
    constructor() {
        this.roles = Roles;
    }
    getRoles(): Array<Role> {
        return this.roles;
    }
    saveRole(role: Role): Array<Role> {
        this.roles.push(role);
        return this.roles;
     }
    // delete(pid:number):Array<Product>{
    //     // var index = this.products.indexOf(prod);
    //     // console.log(index);
    //     // this.products.splice(0,index);
    //     // return this.products;
    //     // alert(`in logic`);


    //     this.products.forEach((ele,idx) =>{
    //         if(ele.ProductId === pid){
    //             console.log(1);
    //             this.products.pop();
    //             //Products.splice(0,idx);
    //         }
    //     });
    //     return this.products;
    // }
}
