import { Role } from './../model/role.model';

export const Roles: Array<Role> = new Array<Role>();
Roles.push(new Role(1, 'Admin'));
Roles.push(new Role(2, 'Operator'));
Roles.push(new Role(3, 'AccessUser'));
