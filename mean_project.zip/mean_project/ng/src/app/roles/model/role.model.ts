export class Role {

  constructor(
    public RoleID: number,
    public RoleName: string,
  ) {  }
}

