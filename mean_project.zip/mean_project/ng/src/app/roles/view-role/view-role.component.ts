import { Component, OnInit } from '@angular/core';
import { Role } from './../model/role.model';
import { Roles } from './../model/role.model.data';
import { RoleLogic } from './../logic/role.logic';
import { RoleService } from 'src/services/RoleService';

@Component({
  selector: 'app-view-role',
  templateUrl: './view-role.component.html',
  styleUrls: ['./view-role.component.css']
})
export class ViewRoleComponent implements OnInit {
  role: Role;
  roles: Array<Role>;
  tableHeaders: Array<string>;
  tablerowcount: number;
  private logic: RoleLogic;
  checkAll: boolean;
  check: boolean;
  token: string;

  constructor(private roleServ: RoleService) {
    this.role = new Role(0, '');
    this.roles = new Array<Role>();
    this.tableHeaders = new Array<string>();
    this.tablerowcount = 0;
    this.token = sessionStorage.getItem('token');

  }

  ngOnInit(): void {
    this.roleServ.getRolesData(this.token).subscribe(
      resp => {
        this.roles = resp.json().data;
      },
      err => {
        console.log(`some error occured : ${ err }`)
      }
    );
  }
}
