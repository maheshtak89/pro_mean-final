export class Person {
  constructor(
    public personId: number,
    public userName: string,
    public firstName: string,
    public middleName: string,
    public lastName: string,
    public gender: string,
    public dob: string,
    public age: string,
    public flatNumber: string,
    public societyName: string,
    public areaName: string,
    public email: string,
    public city: string,
    public state: string,
    public pinCode: string,
    public phoneNo: string,
    public mobileNo: string,
    public physicalDisability: string,
    public maritalStatus: string,
    public education: string,
    public birthSign: string,
    public isAuthorized: string,
    public status: string,
    public userId: number
  ) {}
}

export const Persons = [{}];
