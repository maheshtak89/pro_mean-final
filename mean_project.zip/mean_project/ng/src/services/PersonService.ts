import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { Person } from './../models/app.person.model';
// import { request } from 'http';

@Injectable()
export class PersonService {
  url: string;
  constructor(private http: Http) {
    this.url = 'http://localhost:4040';
  }

  getLoginInfo(person: Person): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      'Content-Type': 'application/json'
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.post(
      `${this.url}/api/users/auth`,
      JSON.stringify(person),
      options
    );
    return resp;
  }

  getPersonData(token: string): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    resp = this.http.get(`${this.url}/api/personinfo`, options);

    return resp;
  }

  getApprovedPerson(token: string): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    resp = this.http.get(`${this.url}/api/personinfoForApprove`, options);
    return resp;
  }

  getPersonDataByUserName(userName: string,token: string): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token,
      userName: userName
    });
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.get(`${this.url}/api/user`, options);

    return resp;
  }

  getPersonDataByEmail(email: string, token: string): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token,
      'email': email
    });
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.get(`${this.url}/api/person/email`, options);
    return resp;
  }

  postPersonData(person: Person, token: string): Observable<Response> {
    let resp: Observable<Response>;

    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    resp = this.http.post(
      `${this.url}/api/personinfo`,
      JSON.stringify(person),
      options
    );
    return resp;
  }

  approvePerson(person: Person, token: string): Observable<Response> {
    let resp: Observable<Response>;

    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token
    });
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.post(
      `${this.url}/api/personinfoapprove/`,
      JSON.stringify(person),
      options
    );
    return resp;
  }

  rejectPerson(personId: number, token: string): Observable<Response> {
    let resp: Observable<Response>;

    const header: Headers = new Headers({
      'Content-Type': 'application/json',
      authorization: 'bearer ' + token
    });
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.delete(
      `${this.url}/api/tempPersoninfoReject/` + personId,
      options
    );
    return resp;
  }
}
