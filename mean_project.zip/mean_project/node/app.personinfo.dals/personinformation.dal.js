var mongoose = require("mongoose");
    //autoIncrement = require("mongoose-auto-increment");
var personmod = require("./../app.personinfo.models/person.model");
var personInfoModel = mongoose.model("PersonInfo");
var tempPersonInfoModel = mongoose.model("TempPersonInfo");

module.exports={

    getPersonInfo:function(request, response){    
        tempPersonInfoModel.find().exec(function(err,resp){
            if(!err){
                if(resp != null){                   
                    response.send({status:200, data:resp});
                
                }else{
                    response.status = 500;
                response.send({status:response.status, error:err});
                }
            }
            else{
                response.status = 500;
                response.send({status:response.status, error:err});
            }
        });
    },

    getPersonInfoforApprove:function(request, response){ 
        personInfoModel.find().exec(function(err,resp){
            if(!err){
                if(resp != null){                   
                    response.send({status:200, data:resp});
                }else{
                    response.status = 500;
                    response.send({status:response.status, error:err});
                }
            }
            else{
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            
        });
    },

    getPersonInfoByUserName:function(request, response){ 
        personInfoModel.find({userName: request.params.userName}).exec(function(err,response){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, data:response});
        });
    },

    getPersonInfoByEmail:function(request, response){ 
        personInfoModel.find({email: request.headers.email}).exec(function(err,res){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, data:res});
        });
    },

    getPersonInfoById:function(request, response){ 
        personInfoModel.find({userId: request.params.userId}).exec(function(err,response){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, data:response});
        });
    },

    postPersonalInfo:function(request, response){
        var isAdmin = request.body.isAuthorized;   
        let condition={
        personId : request.body.personId,
        }
        // personInfoModel.find().sort({personId: -1}).limit(1).exec(function(err, res) {
        //     var maxpersonid= res[0].personId;
        //     if (err) {
        //         response.statuscode = 404;
        //         response.send({ status: response.statuscode, error: err });
        //       }
        //       var personId= maxpersonid + 1;

                if(isAdmin==="true"){
                    personInfoModel.findOne(condition, function(err, resp){
                        console.log(JSON.stringify(resp));
                        if(!err){
                        if(resp != null){
                            console.log("Person information already exist ");
                            response.statuscode = 200;
                            response.send({ status: response.statuscode, message: "Person Information already exist..!" });
                        } else{

                            personInfoModel.find().sort({personId: -1}).limit(1).exec(function(err, res) {
                                var maxpersonid= res[0].personId;
                                if (err) {
                                    response.statuscode = 404;
                                    response.send({ status: response.statuscode, error: err });
                                    }
                                    var personId= maxpersonid + 1;
                                var personInfo = {
                                    personId: personId,
                                    firstName: request.body.firstName,
                                    middleName: request.body.middleName,
                                    lastName: request.body.lastName,
                                    gender: request.body.gender,
                                    dob: request.body.dob,
                                    age:  request.body.age,
                                    flatNumber: request.body.flatNumber,
                                    societyName: request.body.societyName,
                                    areaName: request.body.areaName,
                                    email: request.body.email,
                                    city: request.body.city,
                                    state: request.body.state,
                                    pinCode: request.body.pinCode,
                                    phoneNo: request.body.phoneNo,                 
                                    mobileNo:request.body.mobileNo,
                                    physicalDisability:request.body.physicalDisability,
                                    maritalStatus:request.body.maritalStatus,
                                    education: request.body.education,
                                    birthSign:request.body.birthSign,                       
                                    isAuthorized: request.body.isAuthorized,
                                    userId:request.body.userId,
                                    status: "approved"
                                }

                                personInfoModel.create(personInfo, function(err,respp){
                                    if(!err){
                                        if(respp != null){
                                            response.send({status:200, message:"Person Information Added Successfully"});                            
                                        }
                                        else{
                                            response.send({status:404, message:"Person Information Failed To Save"});                            
                                        }
                                    }
                                    else{
                                        response.status = 500;
                                        response.send({status:response.status, error:err});
                                    }                            
                                });
                            });
                        }
                    }
                    else{
                        console.log(err);
                    }
                    });
                }
                else{

                    tempPersonInfoModel.find().sort({personId: -1}).limit(1).exec(function(err, res) {
                        var maxpersonid= res[0].personId;
                        if (err) {
                            response.statuscode = 404;
                            response.send({ status: response.statuscode, error: err });
                            }
                            var personId= maxpersonid + 1;

                        var personInfo = {
                        personId: personId,
                        firstName: request.body.firstName,
                        middleName: request.body.middleName,
                        lastName: request.body.lastName,
                        gender: request.body.gender,
                        dob: request.body.dob,
                        age:  request.body.age,
                        flatNumber: request.body.flatNumber,
                        societyName: request.body.societyName,
                        areaName: request.body.areaName,
                        email: request.body.email,
                        city: request.body.city,
                        state: request.body.state,
                        pinCode: request.body.pinCode,
                        phoneNo: request.body.phoneNo,                 
                        mobileNo:request.body.mobileNo,
                        physicalDisability:request.body.physicalDisability,                 
                        maritalStatus:request.body.maritalStatus,
                        education: request.body.education,
                        birthSign:request.body.birthSign,                       
                        isAuthorized: request.body.isAuthorized,
                        userId:request.body.userId,
                        status: "pending"
                        }
                        tempPersonInfoModel.create(personInfo, function(err,respp){
                            if(!err){
                                if(respp != null){
                                    response.send({status:200, message:"Person Information Added Successfully"});                            
                                }
                                else{response.send({status:404, message:"Person Information Failed To Save"});                            
                                }
                            }
                            else{
                                response.status = 500;
                                response.send({status:response.status, error:err});
                            }                            
                        });
                    });
                }
        // });
    },

    approvePersonInfo:function(request, response){
        var personInfo = {
            personId:request.body.personId,
            firstName: request.body.firstName,
            middleName: request.body.middleName,
            lastName: request.body.lastName,
            gender: request.body.gender,
            dob: request.body.dob,
            age:  request.body.age,
            flatNumber: request.body.flatNumber,
            societyName: request.body.societyName,
            areaName: request.body.areaName,
            email: request.body.email,
            city: request.body.city,
            state: request.body.state,
            pinCode: request.body.pinCode,
            phoneNo: request.body.phoneNo,                 
            mobileNo:request.body.mobileNo,
            physicalDisability:request.body.physicalDisability,
            maritalStatus:request.body.maritalStatus,
            education: request.body.education,
            birthSign:request.body.birthSign,                       
            isAuthorized: request.body.isAuthorized,
            userId:request.body.userId,
            status: "approved"
        }
        let condition = {
            'personId': request.body.personId
        }
        tempPersonInfoModel.deleteOne(condition, function(err,respp){
            if(!err){
                if(respp != null){
                    personInfoModel.create(personInfo, function(err,res){
                        if(!err){
                            if(res != null){
                                response.send({status:200, message:"Person Information Added Successfully"});                            
                            }
                            else{
                                response.send({status:404, message:"Person Information Failed To Save"});                            
                            }
                        }
                        else{
                            response.status = 500;
                            response.send({status:response.status, error:err});
                        }                            
                    });                           
                }
                else{response.send({status:404, message:"Person Information Failed To Save"});                            
                }
            }
            else{
                response.status = 500;
                response.send({status:response.status, error:err});
            }                            
        });
    },
          
    putPersonInfo: function(request, response){
        var personInfo = {
            personId:request.body.personId,
            firstName: request.body.firstName,
            middleName: request.body.middleName,
            lastName: request.body.lastName,
            gender: request.body.gender,
            dob: request.body.dob,
            age:  request.body.age,
            flatNumber: request.body.flatNumber,
            societyName: request.body.societyName,
            areaName: request.body.areaName,
            email: request.body.email,
            city: request.body.city,
            state: request.body.state,
            pinCode: request.body.pinCode,
            phoneNo: request.body.phoneNo,                 
            mobileNo:request.body.mobileNo,
            physicalDisability:request.body.physicalDisability,                 
            maritalStatus:request.body.maritalStatus,
            education: request.body.education,
            birthSign:request.body.birthSign,  
            userId:request.body.userId,                     
            isAuthorized: request.body.isAuthorized
        }

        tempPersonInfoModel.create(personInfo, function(err,response){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, Message:"Person Information Updated Successfully. Approve will soon."});
        });
    },

    getPersonInfoByUserId: function(request, response){  
        let userId ={
            userId: request.params.userId   
        }

        personInfoModel.findOne(userId).exec(function(err, response){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, data:response});
        });
    },

    getPersonInfoByStatus: function(request, response){
        var reqStatus = request.params.status;
        var persInfo=[];

        if(reqStatus==="approved"){
            personInfoModel.find().exec(function(err,response){
                if(err){
                    response.status = 500;
                    response.send({status:response.status, error:err});
                }
                else{
                    
                    for(var i=0; i<response.length; i++){
                        persInfo[i] = {
                            userId:response[i].userId,
                            fullName:response[i].firstName+" "+response[i].middleName+" "+response[i].lastName,
                            dob:response[i].dob,
                            mobile:response[i].mobileNo,
                            email:response[i].email,
                            city:response[i].city,
                            status:response[i].status
                        }
                    }
                    response.send({status:200, data:persInfo});
                } 
            });
            } 
        else{
            var condition = {status:reqStatus}
            tempPersonInfoModel.find(condition).exec(function(err,response){
                if(err){
                    response.status = 500;
                    response.send({status:response.status, error:err});
                }
                else{
                    
                    for(var i=0; i<response.length; i++){
                        persInfo[i] = {
                            userId:response[i].userId,
                            fullName:response[i].firstName+" "+response[i].middleName+" "+response[i].lastName,
                            dob:response[i].dob,
                            mobile:response[i].mobileNo,
                            email:response[i].email,
                            city:response[i].city,
                            status:response[i].status
                        }
                    }
                    response.send({status:200, data:persInfo});
                }
            });
        }

    },

    doApprovePerson: function(request, response){
        userId={
            userId:request.params.userId
        }

        tempPersonInfoModel.find(userId).exec(function(err,response){
            
            if(response.length > 0) {
            var personInfo = {
                personId:response[0].personId,
                firstName: response[0].firstName,
                middleName: response[0].middleName,
                lastName: response[0].lastName,
                gender: response[0].gender,
                dob: response[0].dob,
                age:  response[0].age,
                flatNumber: response[0].flatNumber,
                societyName: response[0].societyName,
                areaName: response[0].areaName,
                email: response[0].email,
                city: response[0].city,
                state: response[0].state,
                pinCode: response[0].pinCode,
                phoneNo: response[0].phoneNo,                 
                mobileNo: response[0].mobileNo,
                physicalDisability: response[0].physicalDisability,                 
                maritalStatus: response[0].maritalStatus,
                education: response[0].education,
                birthSign: response[0].birthSign,  
                userId: response[0].userId,                     
                isAuthorized: response[0].isAuthorized,
                status:"approved"
            }

            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }

            personInfoModel.create(personInfo, function(err,response){
                if(err){
                    response.status = 500;
                    response.send({status:response.status, error:err});
                }
            });
        
            tempPersonInfoModel.deleteOne(userId, function(err,response){
                if(err){
                    response.status = 500;
                    response.send({status:response.status, error:err});
                }
            });
            response.send({status: 200, message:"Person Information has been approved..!"});
            }
        });
    },

    doRejectPerson: function(request, response){
        personId={
            personId: request.params.personId
        }
        tempPersonInfoModel.deleteOne(personId, function(err,response){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
        });
    },

    searchByUserName: function(request, response){
        firstName={
            firstName : request.params.userName 
        }


        personInfoModel.find({firstName: request.params.userName}).exec(function(err,response){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, data:response});
        });
    }

}