var express = require('express');
var instance = express();
module.exports= instance;

var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

var cors = require('cors');
instance.use(cors());

var bodyParser = require('body-parser');
instance.use(bodyParser.urlencoded({ extended: false }));
instance.use(bodyParser.json());

var roles = require('./app.personinfo.dals/roles.dals');
var users = require('./app.personinfo.dals/users.dals');
var auth = require('./app.personinfo.common/authentication');
var personInfo = require('./app.personinfo.dals/personinformation.dal');

var connection= mongoose.connect(
  'mongodb://localhost/meanDB',
  { useNewUrlParser: true }
);

module.exports= connection;

var dbConnect = mongoose.connection;
if(!dbConnect) {
  console.log('Connection is established');
  return;
}

var jwtSettings = {
    jwtSecret: 'qWhdiwywsnW26dwcsQkshd^sdh'
  };

//Set the secrete key with express
instance.set( 'jwtSecret' , jwtSettings.jwtSecret );

instance.post('/api/users/auth', function(request, response) {

    auth.authUser(request, response);

});

//Role get Operation
instance.get('/api/role', function( request , response ) {   
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken == false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        roles.getRoles( request , response );
    }
});

//Role Post Operation
instance.post('/api/role', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken == false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        roles.postRoles( request , response );
    }
});

//Role Update Operation
instance.put('/api/role/:id', function( request , response ) { 
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        roles.updateRoles( request , response );
    }
});

//Role delete Operation
instance.delete('/api/role/:id', function( request , response ) { 
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        roles.deleteRoles( request , response );
    }
});

//Users get Operation
instance.get('/api/users', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.getUsers(request, response);
    }
});
// get operator list for role no #2 only
instance.get('/api/oprators', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.getOperators(request, response);
    }
});

//Users get Operation
instance.get('/api/user/userName', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    var userName = request.headers.username;
    if(receivedToken == false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.getUserByUserName(request, response);
    }
});

instance.get('/api/user/email', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    var email = request.headers.email;
    if(receivedToken == false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.getUserByEmail(request, response);
    }
});

//Users Post Operation
instance.post('/api/users', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.postUser(request, response);
    }
});

//Users Update Operation
instance.put('/api/users/:id', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.updateUser(request, response);
    }
});


instance.put('/api/user/password', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
        users.updateUserPassword(request, response);
    }
});

//Users delete Operation
instance.delete('/api/users/remove/:userId', function( request , response ) {
    var tokenReceived = request.headers.authorization.split(' ')[1];
    var receivedToken = auth.verifyUser(tokenReceived);
    if(receivedToken ==false){
        response.send({ success: false, message: 'Token verification failed' });
    } else{
       users.deleteUser(request,response);
    }
});

//Person Information GET Operation
instance.get('/api/personinfo',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfo(request, response);
    }
});

instance.get('/api/personinfoForApprove',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfoforApprove(request, response);
    }
});

instance.get('/api/getPersonInfoByUserName',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfoByUserName(request, response);
    }
});

instance.get('/api/person/email',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfoByEmail(request, response);
    }
});

instance.get('/api/gettemppersoninfo',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfo(request, response);
    }
});

instance.get('/api/personinfo/id/:userId',function(request, response){  
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfoById(request, response);
    }
});

//Person Information POST Operation
instance.post('/api/personinfo',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.postPersonalInfo(request, response)
    }
});

//Person Information PUT Operation
instance.put('/api/personinfo',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.putPersonInfo(request, response)
    }
});

instance.post('/api/personinfoapprove',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, Message:'Token verification failed'});
    }
    else{
        personInfo.approvePersonInfo(request, response)
    }
});

instance.get('/api/personinfo/byuserid/:userId', function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
      if(isValToken==false){
        response.send({status:500, error:'Token verification failed'})
      }
      else{
        personInfo.getPersonInfoByUserId(request, response)
      }
  });

instance.get('/api/personinfo/:status',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfoByStatus(request, response)
    }
});

instance.get('/api/personinfo',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, message:'Token verification failed'});
    }
    else{
        personInfo.getPersonInfo(request, response)
    }
});

instance.get('/api/temppersoninfo/approve/:userId',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, message:'Token verification failed'});
    }
    else{
        personInfo.doApprovePerson(request, response)
    }
});

instance.delete('/api/tempPersoninfoReject/:personId',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken==false){
        response.send({success:false, message:'Token verification failed'});
    }
    else{
        personInfo.doRejectPerson(request, response)
    }
});

instance.get('/api/searchuser/:userName',function(request, response){
    var isValToken = auth.verifyUser(request.headers.authorization.split(' ')[1])
    if(isValToken == false){
        response.send({success:false, message:'Token verification failed'});
    }
    else{
        personInfo.searchByUserName(request, response)
    }
});

// to create server
instance.listen(4040, function() {
  console.log('Started listening on port 4040');
});